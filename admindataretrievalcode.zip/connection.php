<?php
 $conn= mysqli_connect('localhost','root','','axiom')or die("connection Failed:" . mysqli_connect_error());
//mysqli_connect('localhost','root','');
//mysqli_select_db('axiom');
?>