<?php
include_once('connection.php');
//include_once 'include/connection.php';
$query="select * from carrier";
//$query="SELECT * FROM carrier";
$result=mysqli_query($conn,$query);
$resultCheck = mysqli_num_rows($result);
?>

<!DOCTYPE html>
<html>
     <title>
         <head> Fetch Data From Database </head>
     </title>
<body>
    <table align="center" border="1px" style="width:900px;line-height:40px;">
        <tr>
         <th colspan="9"><h2>Student Record<h2></th> <th><h2> Actions <h2></th>
        </tr> 
        <tr>  
            <th> ID </th>
            <th> name </th>
            <th> contact </th>
            <th> email  </th>
            <th>collegeName </th>
            <th> degree </th>
            <th> year </th>
            <th> stream </th>
            <th> address</th>
            
        </tr>
    <?php
    //if($resultCheck > 0){
     while($row = mysqli_fetch_assoc($result))
     {
    ?>     
         <tr>
             <td><?php echo $row['id'] ; ?></td> 
             <td><?php echo $row['name']; ?></td> 
             <td><?php echo $row['contact'] ;?></td> 
             <td><?php echo $row['email'] ;?></td>;
             <td><?php echo $row['CollegeName'] ;?></td> 
             <td><?php echo $row['degree'] ;?></td> 
             <td><?php echo $row['year'] ;?></td> 
             <td><?php echo $row['stream'] ;?></td> 
             <td><?php echo $row['address'] ;?></td>
             

                 
             
         </tr>
    <?PHP     
     }
   // }
    ?> 
    </table>
</body>
</html>        

