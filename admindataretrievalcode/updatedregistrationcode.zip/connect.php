<?php
  if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])){
      $conn= mysqli_connect('localhost','root','','event') or die("connection Failed:" . mysqli_connect_error());
      if(isset($_POST['name']) && isset($_POST['contact']) && isset($_POST['email']) && isset($_POST['collegeName']) && isset($_POST['degree']) && isset($_POST['year']) && isset($_POST['stream']) && isset($_POST['address']) && isset($_POST['gender'])){
       $name= $_POST['name'];  
       $contact= $_POST['contact'];
       $email= $_POST['email'];
       $collegeName= $_POST['collegeName'];
       $degree= $_POST['degree'];  
       $year= $_POST['year'];
       $stream= $_POST['stream'];
       $address= $_POST['address'];
       $gender= $_POST['gender'];
       
       $sql = " INSERT INTO reguser ( name, contact, email, collegeName, degree, year, stream, address, gender)
VALUES ('$name','$contact','$email','$collegeName','$degree','$year','$stream','$address','$gender')";

       $query = mysqli_query($conn,$sql) ;
       if($query)
       {
           echo 'Entery Successfull' . mysqli_connect_error();
       }
       else{
           echo 'Error Occured' . mysqli_connect_error();
       }
      }
  }
?>